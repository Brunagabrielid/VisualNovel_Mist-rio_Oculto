extends Control
## Menu principal (Figura 13 do TCC).
## - O botão muda de "Iniciar Jogo" para "Continuar Jogo" quando já existe progresso salvo (Figura 16).
## - Ao iniciar, o jogador informa o nome do save (RF01 / Cadastrar Save).

@onready var botao_jogar: Button = $"VBoxContainer/Jogar"
@onready var botao_creditos: Button = $"VBoxContainer/Créditos"
@onready var botao_sair: Button = $"VBoxContainer/Sair"
@onready var botao_config: Button = $"VBoxContainer/Configurações"
@onready var titulo: Label = $"VBoxContainer/Título"


func _ready() -> void:
	# Os textos são definidos aqui (e não no .tscn) para serem traduzidos conforme o idioma (RF04).
	titulo.text = "\n" + tr("MISTÉRIO OCULTO")
	botao_jogar.text = "CONTINUAR JOGO" if Database.tem_progresso() else "INICIAR JOGO"
	botao_creditos.text = "CRÉDITOS"
	botao_sair.text = "SAIR"
	botao_config.text = "CONFIGURAÇÕES"


# ---------- Botões ----------

func _on_jogar_pressed() -> void:
	_pedir_nome()


func _on_créditos_pressed() -> void:
	print("Créditos")


func _on_configuracoes_pressed() -> void:
	get_tree().change_scene_to_file("res://configuracoes.tscn")


func _on_sair_pressed() -> void:
	Game.sair_do_jogo()  # RF07: salva o progresso antes de fechar


# ---------- Cadastrar Save (RF01) ----------

func _pedir_nome() -> void:
	var janela := ConfirmationDialog.new()
	janela.title = tr("Qual é o seu nome?")
	janela.ok_button_text = tr("Confirmar")
	janela.cancel_button_text = tr("Cancelar")
	janela.exclusive = true

	var caixa := VBoxContainer.new()
	janela.add_child(caixa)

	var campo := LineEdit.new()
	campo.max_length = Database.TAMANHO_MAX_NOME
	campo.placeholder_text = tr("Digite seu nome (até 20 caracteres)")
	campo.text = Database.nome_atual
	campo.custom_minimum_size = Vector2(380, 40)
	caixa.add_child(campo)

	var erro := Label.new()
	erro.text = tr("O nome é obrigatório.")
	erro.visible = false
	caixa.add_child(erro)

	add_child(janela)
	janela.confirmed.connect(func() -> void:
		var nome := campo.text.strip_edges()
		if not Database.nome_valido(nome):
			erro.visible = true
			janela.popup_centered()
			return
		janela.queue_free()
		_usar_nome(nome))
	janela.canceled.connect(janela.queue_free)
	campo.text_submitted.connect(func(_t: String) -> void: janela.get_ok_button().pressed.emit())

	janela.popup_centered()
	campo.grab_focus()
	campo.select_all()


func _usar_nome(nome: String) -> void:
	if not Database.existe_perfil(nome):
		# Save novo: cria o registro e começa do início.
		if Database.criar_perfil(nome):
			Game.mostrar_mensagem("Registro salvo com sucesso!")  # Msg1
			_iniciar_partida(false)
		return

	# Cenário alternativo do caso de uso: já existe um save com esse nome.
	var janela := ConfirmationDialog.new()
	janela.title = tr("Qual é o seu nome?")
	janela.dialog_text = tr("Já existe um save com o nome “%s”. O que deseja fazer?") % nome
	janela.ok_button_text = tr("Continuar save")
	janela.cancel_button_text = tr("Cancelar")
	janela.exclusive = true
	var excluir := janela.add_button(tr("Excluir save"), true, "excluir")
	excluir.focus_mode = Control.FOCUS_ALL
	add_child(janela)

	janela.confirmed.connect(func() -> void:
		janela.queue_free()
		Database.carregar_perfil(nome)
		_iniciar_partida(Database.tem_progresso()))
	janela.custom_action.connect(func(acao: StringName) -> void:
		if acao == &"excluir":
			janela.queue_free()
			Database.excluir_perfil(nome)
			Game.mostrar_mensagem("Save excluído.")
			botao_jogar.text = "INICIAR JOGO")
	janela.canceled.connect(janela.queue_free)
	janela.popup_centered()


func _iniciar_partida(retomar: bool) -> void:
	Game.retomar = retomar
	Game.mostrar_mensagem("Jogo iniciado!")  # Msg5
	get_tree().change_scene_to_file("res://introducao.tscn")
