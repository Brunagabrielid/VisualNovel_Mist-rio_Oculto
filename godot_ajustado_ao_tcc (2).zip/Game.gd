extends Node
## Estado global da partida: fundo/personagem atuais, mensagens do sistema (Msg1 a Msg7 do TCC),
## estilo acessível do texto (RF02) e traduções da interface (RF04).

var bg
var character
var fundo_atual: String = ""
var personagem_atual: String = ""

## Verdadeiro quando o jogador escolheu "Continuar Jogo" (retoma da última linha salva).
var retomar: bool = false

## Cores de legenda disponíveis (sem vermelho/verde, conforme a paleta do TCC e WCAG 1.4.1).
const CORES_LEGENDA := {
	"branco": Color(1, 1, 1),
	"amarelo": Color(1, 0.92, 0.35),
	"azul": Color(0.65, 0.85, 1),
}

## Fontes disponíveis (pequena coleção de fontes de sistema - Figura 18 do TCC).
const FONTES := ["padrao", "serifada", "monoespacada", "instrument"]


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_registrar_traducoes()
	get_tree().set_auto_accept_quit(false)


func _notification(what: int) -> void:
	# RF07: ao sair, todo o progresso é salvo.
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		sair_do_jogo()


# ---------- Cena: fundo e personagem (usados pelo roteiro) ----------

func set_bg(path):
	if not is_instance_valid(bg):
		bg = get_tree().current_scene.get_node("BG_imag")

	var tex = load(path)
	if tex:
		bg.texture = tex
		fundo_atual = path
	else:
		push_warning("Imagem de fundo não encontrada: " + str(path))


func set_character(path):
	if not is_instance_valid(character):
		character = get_tree().current_scene.get_node("Personagem")

	var tex = load(path)
	if tex:
		character.texture = tex
		personagem_atual = path
	else:
		push_warning("Imagem de personagem não encontrada: " + str(path))


# ---------- Progresso ----------

func registrar_linha(id_linha: String) -> void:
	Database.registrar_progresso(id_linha, fundo_atual, personagem_atual)


func sair_do_jogo() -> void:
	Database.salvar_perfil()
	mostrar_mensagem("Saindo do sistema!")  # Msg7
	await get_tree().create_timer(0.6).timeout
	get_tree().quit()


# ---------- Mensagens do sistema (Msg1 a Msg7) ----------

func mostrar_mensagem(texto: String) -> void:
	var camada := CanvasLayer.new()
	camada.layer = 200
	camada.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(camada)

	var centro := CenterContainer.new()
	camada.add_child(centro)
	centro.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
	centro.offset_top = 24
	centro.mouse_filter = Control.MOUSE_FILTER_IGNORE

	var painel := PanelContainer.new()
	painel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color.BLACK
	estilo.set_border_width_all(2)
	estilo.border_color = Color.WHITE
	estilo.set_content_margin_all(14)
	painel.add_theme_stylebox_override("panel", estilo)
	centro.add_child(painel)

	var rotulo := Label.new()
	rotulo.text = tr(texto)
	rotulo.add_theme_font_size_override("font_size", 22)
	painel.add_child(rotulo)

	painel.modulate.a = 0.0
	var tween := create_tween()
	tween.tween_property(painel, "modulate:a", 1.0, 0.2)
	tween.tween_interval(1.6)
	tween.tween_property(painel, "modulate:a", 0.0, 0.3)
	tween.tween_callback(camada.queue_free)


# ---------- Estilo acessível do texto (RF02) ----------

func criar_fonte(chave: String) -> Font:
	if chave == "instrument":
		return load("res://Instrument_Serif/InstrumentSerif-Regular.ttf")
	var fonte := SystemFont.new()
	match chave:
		"serifada":
			fonte.font_names = PackedStringArray(["Georgia", "Times New Roman", "serif"])
		"monoespacada":
			fonte.font_names = PackedStringArray(["Consolas", "Courier New", "monospace"])
		_:
			fonte.font_names = PackedStringArray(["Open Sans", "Arial", "sans-serif"])
	return fonte


## Aplica tamanho, tipo, cor, espaçamento e alto contraste ao balão de diálogo.
func aplicar_estilo_balao(painel: PanelContainer, rotulo_dialogo: RichTextLabel, rotulo_nome: RichTextLabel) -> void:
	var c: Dictionary = Database.config
	var tamanho := int(c["tamanho_texto"])
	var alto_contraste := bool(c["alto_contraste"])
	var cor: Color = CORES_LEGENDA.get(str(c["cor_legenda"]), Color.WHITE)
	var fonte := criar_fonte(str(c["fonte"]))

	for r in [rotulo_dialogo, rotulo_nome]:
		r.add_theme_font_size_override("normal_font_size", tamanho)
		r.add_theme_font_size_override("bold_font_size", tamanho)
		r.add_theme_font_override("normal_font", fonte)
		r.add_theme_font_override("bold_font", fonte)
		r.add_theme_color_override("default_color", cor)
	rotulo_dialogo.add_theme_constant_override("line_separation", int(c["espacamento"]))
	# O nome do personagem não fica mais semitransparente: contraste total.
	rotulo_nome.modulate = Color(1, 1, 1, 1)

	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0, 0, 0, 1.0 if alto_contraste else 0.82)
	estilo.set_corner_radius_all(5)
	if alto_contraste:
		estilo.set_border_width_all(3)
		estilo.border_color = Color.WHITE
	painel.add_theme_stylebox_override("panel", estilo)


# ---------- Traduções da interface (RF04) ----------
# As chaves são os próprios textos em português; "en" fornece o inglês.
# (Os diálogos da história usam o sistema de tradução do Dialogue Manager.)

func _registrar_traducoes() -> void:
	var t := Translation.new()
	t.locale = "en"
	var textos := {
		"MISTÉRIO OCULTO": "HIDDEN MYSTERY",
		"INICIAR JOGO": "START GAME",
		"CONTINUAR JOGO": "CONTINUE GAME",
		"CRÉDITOS": "CREDITS",
		"CONFIGURAÇÕES": "SETTINGS",
		"SAIR": "QUIT",
		"CONTROLAR SOM": "SOUND CONTROL",
		"CONFIGURAR TEXTO": "TEXT SETTINGS",
		"CONFIGURAR IDIOMA": "LANGUAGE SETTINGS",
		"Altura do som (música)": "Volume (music)",
		"Efeitos sonoros": "Sound effects",
		"SEM SOM": "NO SOUND",
		"Tipo da fonte": "Font type",
		"Padrão (Open Sans)": "Default (Open Sans)",
		"Serifada": "Serif",
		"Monoespaçada": "Monospaced",
		"Instrument Serif (do jogo)": "Instrument Serif (game font)",
		"Tamanho da fonte": "Font size",
		"Cor da legenda": "Caption color",
		"Branco": "White",
		"Amarelo": "Yellow",
		"Azul claro": "Light blue",
		"Espaçamento entre linhas": "Line spacing",
		"Velocidade do texto": "Text speed",
		"Modo alto contraste": "High contrast mode",
		"Prévia: A detetive Mina observa a cena em silêncio.": "Preview: Detective Mina watches the scene in silence.",
		"Idioma selecionado": "Selected language",
		"Português (Brasil) - padrão": "Português (Brasil) - default",
		"Restaurar padrões": "Restore defaults",
		"Voltar": "Back",
		"PAUSAR JOGO": "PAUSE GAME",
		"SAIR DO JOGO": "QUIT GAME",
		"Ao sair, todo o progresso será salvo.": "When you quit, all progress will be saved.",
		"Qual é o seu nome?": "What is your name?",
		"Digite seu nome (até 20 caracteres)": "Type your name (up to 20 characters)",
		"Confirmar": "Confirm",
		"Cancelar": "Cancel",
		"Continuar save": "Continue save",
		"Excluir save": "Delete save",
		"O nome é obrigatório.": "The name is required.",
		"Já existe um save com o nome “%s”. O que deseja fazer?": "A save named “%s” already exists. What would you like to do?",
		"Registro salvo com sucesso!": "Record saved successfully!",
		"Texto ajustado com sucesso!": "Text adjusted successfully!",
		"Som ajustado com sucesso!": "Sound adjusted successfully!",
		"Idioma atualizado com sucesso!": "Language updated successfully!",
		"Jogo iniciado!": "Game started!",
		"Jogo pausado!": "Game paused!",
		"Saindo do sistema!": "Leaving the system!",
		"Nenhuma alteração encontrada": "No changes found",
		"Save excluído.": "Save deleted.",
	}
	for chave in textos.keys():
		t.add_message(chave, textos[chave])
	TranslationServer.add_translation(t)
