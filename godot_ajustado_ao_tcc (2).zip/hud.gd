extends CanvasLayer
## HUD da partida (Figuras 15 e 16 do TCC):
##  - botão de pausa (canto superior esquerdo) -> painel "PAUSAR JOGO" / "SAIR DO JOGO" (RF06 e RF07)
##  - botão "CONFIGURAÇÕES" (canto superior direito) -> abre a tela de configurações sobre o jogo (RF02/RF03/RF04)

var _painel_pausa: PanelContainer
var _pausado: bool = false
var _config_aberta: bool = false


func _ready() -> void:
	layer = 110  # acima do balão de diálogo (camada 100)
	process_mode = Node.PROCESS_MODE_ALWAYS

	var raiz := Control.new()
	raiz.mouse_filter = Control.MOUSE_FILTER_IGNORE  # cliques fora dos botões continuam avançando o diálogo
	add_child(raiz)
	raiz.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	# Botão de pausa
	var btn_pausa := _botao("II", Color.WHITE, Color.BLACK)
	btn_pausa.tooltip_text = tr("PAUSAR JOGO")
	btn_pausa.position = Vector2(16, 16)
	btn_pausa.custom_minimum_size = Vector2(56, 56)
	btn_pausa.pressed.connect(_alternar_pausa)
	raiz.add_child(btn_pausa)

	# Botão de configurações
	var btn_config := _botao("CONFIGURAÇÕES", Color.WHITE, Color.BLACK)
	btn_config.custom_minimum_size = Vector2(250, 56)
	btn_config.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	btn_config.offset_left = -266
	btn_config.offset_right = -16
	btn_config.offset_top = 16
	btn_config.offset_bottom = 72
	btn_config.pressed.connect(_abrir_config)
	raiz.add_child(btn_config)

	# Painel de pausa (Figura 16)
	_painel_pausa = PanelContainer.new()
	_painel_pausa.visible = false
	_painel_pausa.position = Vector2(16, 84)
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0, 0, 0, 0.88)
	estilo.set_border_width_all(2)
	estilo.border_color = Color.WHITE
	estilo.set_content_margin_all(18)
	_painel_pausa.add_theme_stylebox_override("panel", estilo)
	raiz.add_child(_painel_pausa)

	var coluna := VBoxContainer.new()
	coluna.add_theme_constant_override("separation", 12)
	_painel_pausa.add_child(coluna)

	var titulo := Label.new()
	titulo.text = "PAUSAR JOGO"
	titulo.add_theme_font_size_override("font_size", 26)
	coluna.add_child(titulo)

	var btn_sair := _botao("SAIR DO JOGO", Color.WHITE, Color.BLACK)
	btn_sair.custom_minimum_size = Vector2(300, 52)
	btn_sair.pressed.connect(Game.sair_do_jogo)
	coluna.add_child(btn_sair)

	var aviso := Label.new()
	aviso.text = "Ao sair, todo o progresso será salvo."
	aviso.add_theme_font_size_override("font_size", 16)
	coluna.add_child(aviso)


func _botao(texto: String, fundo: Color, cor_texto: Color) -> Button:
	var b := Button.new()
	b.text = texto
	var normal := StyleBoxFlat.new()
	normal.bg_color = fundo
	normal.set_content_margin_all(8)
	var hover: StyleBoxFlat = normal.duplicate()
	hover.bg_color = Color(0.82, 0.82, 0.82)
	var foco: StyleBoxFlat = normal.duplicate()
	foco.set_border_width_all(4)
	foco.border_color = Color.BLACK
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("pressed", hover)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("focus", foco)
	for nome_cor in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		b.add_theme_color_override(nome_cor, cor_texto)
	b.add_theme_font_size_override("font_size", 22)
	return b


# ---------- Pausar jogo (RF06) ----------

func _alternar_pausa() -> void:
	_pausado = not _pausado
	get_tree().paused = _pausado
	_painel_pausa.visible = _pausado
	if _pausado:
		Game.mostrar_mensagem("Jogo pausado!")  # Msg6
		Database.salvar_perfil()


# ---------- Configurações sobre o jogo ----------

func _abrir_config() -> void:
	if _config_aberta:
		return
	_config_aberta = true
	var estava_pausado := _pausado
	get_tree().paused = true

	var cena: PackedScene = load("res://configuracoes.tscn")
	var tela = cena.instantiate()
	tela.como_overlay = true

	var camada := CanvasLayer.new()
	camada.layer = 120
	camada.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(camada)
	camada.add_child(tela)

	tela.fechado.connect(func() -> void:
		camada.queue_free()
		_config_aberta = false
		get_tree().paused = estava_pausado)
