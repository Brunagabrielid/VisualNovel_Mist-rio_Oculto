extends Control
## Cena da partida: carrega a história (Dialogue Manager), o HUD e, se o jogador escolheu
## "Continuar Jogo", retoma do último ponto salvo.

func _ready() -> void:
	# Espera um quadro para que a cena atual já esteja registrada (Game.set_bg precisa dela).
	await get_tree().process_frame

	var recurso: Resource = load("res://backgrounds/cena1intro.dialogue")
	var titulo: String = "introducao"

	if Game.retomar and Database.tem_progresso():
		var dados: Dictionary = Database.config
		if str(dados["ultimo_fundo"]) != "":
			Game.set_bg(str(dados["ultimo_fundo"]))
		if str(dados["ultimo_personagem"]) != "":
			Game.set_character(str(dados["ultimo_personagem"]))
		titulo = str(dados["ultima_linha"])  # o Dialogue Manager aceita o id da linha como ponto de partida
	else:
		Database.limpar_progresso()
		Game.fundo_atual = ""
		Game.personagem_atual = ""
	Game.retomar = false

	var hud := preload("res://hud.gd").new()
	add_child(hud)

	DialogueManager.dialogue_ended.connect(_on_dialogue_ended)
	DialogueManager.show_dialogue_balloon(recurso, titulo)


func _on_dialogue_ended(_recurso: Resource) -> void:
	# A história terminou: zera o progresso (o menu volta a mostrar "Iniciar Jogo").
	Database.limpar_progresso()
	get_tree().paused = false
	get_tree().change_scene_to_file("res://menu.tscn")
