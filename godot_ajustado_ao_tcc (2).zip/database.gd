extends Node
## Camada de persistência local (SQLite).
## Implementa a tabela "Salvar_Progresso" do TCC (Tabela 9 - Dicionário de Dados).
## Cada jogador é identificado pelo nome (nome_usuario, PK, máx. 20 caracteres) - RF01.

## Emitido quando o jogador altera uma configuração (o balão de diálogo se atualiza na hora).
signal config_alterada

const CAMINHO_BD := "user://configuracoes.db"
const TAMANHO_MAX_NOME := 20
const BARRAMENTO_MUSICA := "Musica"
const BARRAMENTO_EFEITOS := "Efeitos"

# Valores padrão. Os quatro primeiros seguem exatamente a Tabela 9 do TCC.
const PADROES := {
	"idioma": "pt-BR",
	"tamanho_texto": 16,
	"velocidade_texto": 1.0,
	"volume_musica": 0.5,
	"volume_efeito": 0.5,
	# Campos extras exigidos pelo RF02 (texto), RF03 (som) e RF05/Figura 16 (continuar jogo):
	"fonte": "padrao",
	"cor_legenda": "branco",
	"espacamento": 4,
	"alto_contraste": 0,
	"sem_som": 0,
	"ultima_linha": "",
	"ultimo_fundo": "",
	"ultimo_personagem": "",
}
const CAMPOS := [
	"idioma", "tamanho_texto", "velocidade_texto", "volume_musica", "volume_efeito",
	"fonte", "cor_legenda", "espacamento", "alto_contraste", "sem_som",
	"ultima_linha", "ultimo_fundo", "ultimo_personagem",
]

var db: SQLite
var nome_atual: String = ""
var config: Dictionary = PADROES.duplicate()


func _ready() -> void:
	conectar()
	carregar_ultimo_perfil()
	aplicar_config()


# ---------- Conexão e tabela ----------

func conectar() -> void:
	db = SQLite.new()
	db.path = CAMINHO_BD

	if not db.open_db():
		push_error("Erro ao conectar ao banco de dados: " + db.error_message)
		return

	db.query("""
	CREATE TABLE IF NOT EXISTS Salvar_Progresso (
		nome_usuario TEXT(20) PRIMARY KEY NOT NULL CHECK (length(nome_usuario) BETWEEN 1 AND 20),
		idioma TEXT NOT NULL DEFAULT 'pt-BR',
		tamanho_texto INTEGER NOT NULL DEFAULT 16,
		velocidade_texto REAL NOT NULL DEFAULT 1.0,
		volume_musica REAL NOT NULL DEFAULT 0.5,
		volume_efeito REAL NOT NULL DEFAULT 0.5,
		fonte TEXT NOT NULL DEFAULT 'padrao',
		cor_legenda TEXT NOT NULL DEFAULT 'branco',
		espacamento INTEGER NOT NULL DEFAULT 4,
		alto_contraste INTEGER NOT NULL DEFAULT 0,
		sem_som INTEGER NOT NULL DEFAULT 0,
		ultima_linha TEXT NOT NULL DEFAULT '',
		ultimo_fundo TEXT NOT NULL DEFAULT '',
		ultimo_personagem TEXT NOT NULL DEFAULT '',
		ultimo_acesso INTEGER NOT NULL DEFAULT 0
	);
	""")


# ---------- Perfis (RF01 - Cadastrar Save) ----------

func nome_valido(nome: String) -> bool:
	var limpo := nome.strip_edges()
	return limpo.length() >= 1 and limpo.length() <= TAMANHO_MAX_NOME


func existe_perfil(nome: String) -> bool:
	if db == null:
		return false
	db.query_with_bindings("SELECT nome_usuario FROM Salvar_Progresso WHERE nome_usuario = ?;", [nome])
	return not db.query_result.is_empty()


## Cria o save com o nome informado, levando junto as configurações atuais
## (assim o que o jogador ajustou no menu antes de iniciar não se perde).
func criar_perfil(nome: String) -> bool:
	if db == null or not nome_valido(nome):
		return false
	config["ultima_linha"] = ""
	config["ultimo_fundo"] = ""
	config["ultimo_personagem"] = ""

	var colunas: Array = ["nome_usuario"] + CAMPOS + ["ultimo_acesso"]
	var marcas: Array = []
	var valores: Array = [nome]
	for c in CAMPOS:
		valores.append(config[c])
	valores.append(int(Time.get_unix_time_from_system()))
	for i in colunas.size():
		marcas.append("?")

	var sql := "INSERT INTO Salvar_Progresso (%s) VALUES (%s);" % [", ".join(colunas), ", ".join(marcas)]
	var ok: bool = db.query_with_bindings(sql, valores)
	if not ok:
		push_error("Erro ao criar save: " + db.error_message)
		return false
	nome_atual = nome
	return true


func carregar_perfil(nome: String) -> bool:
	if db == null:
		return false
	db.query_with_bindings("SELECT * FROM Salvar_Progresso WHERE nome_usuario = ?;", [nome])
	if db.query_result.is_empty():
		return false
	var linha: Dictionary = db.query_result[0]
	for chave in PADROES.keys():
		if linha.has(chave):
			config[chave] = linha[chave]
	nome_atual = nome
	salvar_perfil()  # atualiza ultimo_acesso
	return true


func carregar_ultimo_perfil() -> void:
	if db == null:
		return
	db.query("SELECT nome_usuario FROM Salvar_Progresso ORDER BY ultimo_acesso DESC LIMIT 1;")
	if db.query_result.is_empty():
		return
	carregar_perfil(db.query_result[0]["nome_usuario"])


func excluir_perfil(nome: String) -> void:
	if db == null:
		return
	db.query_with_bindings("DELETE FROM Salvar_Progresso WHERE nome_usuario = ?;", [nome])
	if nome == nome_atual:
		nome_atual = ""
		limpar_progresso_memoria()


func tem_progresso() -> bool:
	return nome_atual != "" and str(config["ultima_linha"]) != ""


# ---------- Gravação ----------

func salvar_perfil() -> bool:
	if db == null or nome_atual.is_empty():
		return false
	var trechos: Array = []
	var valores: Array = []
	for c in CAMPOS:
		trechos.append("%s = ?" % c)
		valores.append(config[c])
	valores.append(int(Time.get_unix_time_from_system()))
	valores.append(nome_atual)

	var sql := "UPDATE Salvar_Progresso SET %s, ultimo_acesso = ? WHERE nome_usuario = ?;" % ", ".join(trechos)
	var ok: bool = db.query_with_bindings(sql, valores)
	if not ok:
		push_error("Erro ao salvar: " + db.error_message)
	return ok


## Atualiza as configurações em memória e, se já existe um save ativo, grava no banco.
func atualizar_config(novos: Dictionary) -> void:
	for chave in novos.keys():
		config[chave] = novos[chave]
	salvar_perfil()
	aplicar_config()
	config_alterada.emit()


## Registra o ponto da história (usado pelo "Continuar Jogo" e pelo salvamento automático).
func registrar_progresso(linha: String, fundo: String, personagem: String) -> void:
	config["ultima_linha"] = linha
	config["ultimo_fundo"] = fundo
	config["ultimo_personagem"] = personagem
	salvar_perfil()


func limpar_progresso() -> void:
	limpar_progresso_memoria()
	salvar_perfil()


func limpar_progresso_memoria() -> void:
	config["ultima_linha"] = ""
	config["ultimo_fundo"] = ""
	config["ultimo_personagem"] = ""


# Compatibilidade com o código antigo (o balão de diálogo lia as configurações por aqui).
func carregar_configuracoes() -> Dictionary:
	return config


# ---------- Aplicação das configurações (idioma e som) ----------

func aplicar_config() -> void:
	TranslationServer.set_locale(codigo_locale(str(config["idioma"])))

	var musica := _garantir_barramento(BARRAMENTO_MUSICA)
	var efeitos := _garantir_barramento(BARRAMENTO_EFEITOS)
	AudioServer.set_bus_volume_db(musica, linear_to_db(maxf(float(config["volume_musica"]), 0.0001)))
	AudioServer.set_bus_volume_db(efeitos, linear_to_db(maxf(float(config["volume_efeito"]), 0.0001)))
	# "Sem som" (RF03): silencia o barramento principal sem perder os volumes escolhidos.
	AudioServer.set_bus_mute(0, bool(config["sem_som"]))


## O banco guarda "pt-BR" (como no TCC); a engine usa "pt_BR".
func codigo_locale(idioma: String) -> String:
	return idioma.replace("-", "_")


func _garantir_barramento(nome: String) -> int:
	var indice := AudioServer.get_bus_index(nome)
	if indice == -1:
		AudioServer.add_bus()
		indice = AudioServer.bus_count - 1
		AudioServer.set_bus_name(indice, nome)
		AudioServer.set_bus_send(indice, "Master")
	return indice
