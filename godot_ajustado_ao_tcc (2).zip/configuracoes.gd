extends Control
## Tela de Configurações – segue as Figuras 17 a 20 do TCC:
##   Configurações (hub) -> Controlar Som (RF03) | Configurar Texto (RF02) | Configurar Idioma (RF04)
## As alterações são gravadas automaticamente (sem botão "salvar") e confirmadas com
## as mensagens Msg2, Msg3 e Msg4 dos casos de uso. Se nada mudou: "Nenhuma alteração encontrada".

signal fechado

const ARQUIVO_FUNDO := "res://backgrounds/mansao_salateste.png"
const ATRASO_CONFIRMACAO := 0.6

const MENSAGENS := {
	"som": "Som ajustado com sucesso!",
	"texto": "Texto ajustado com sucesso!",
	"idioma": "Idioma atualizado com sucesso!",
}
const TITULOS := {
	"hub": "CONFIGURAÇÕES",
	"som": "CONTROLAR SOM",
	"texto": "CONFIGURAR TEXTO",
	"idioma": "CONFIGURAR IDIOMA",
}
const ROTULOS_FONTE := {
	"padrao": "Padrão (Open Sans)",
	"serifada": "Serifada",
	"monoespacada": "Monoespaçada",
	"instrument": "Instrument Serif (do jogo)",
}
const CORES_ORDEM := ["branco", "amarelo", "azul"]
const ROTULOS_COR := {"branco": "Branco", "amarelo": "Amarelo", "azul": "Azul claro"}
const IDIOMAS := [
	{"codigo": "en", "rotulo": "English"},
	{"codigo": "pt-BR", "rotulo": "Português (Brasil) - padrão"},
]

## Quando verdadeiro, a tela abre por cima do jogo (botão "Configurações" do HUD).
var como_overlay: bool = false

var _carregando: bool = true
var _pagina_atual: String = "hub"
var _paginas: Dictionary = {}
var _titulo: Label
var _botao_restaurar: Button
var _timer: Timer

var _sl_musica: HSlider
var _sl_efeitos: HSlider
var _chk_sem_som: CheckButton
var _opt_fonte: OptionButton
var _sl_tamanho: HSlider
var _opt_cor: OptionButton
var _sl_espaco: HSlider
var _sl_velocidade: HSlider
var _chk_contraste: CheckButton
var _painel_previa: PanelContainer
var _lbl_previa: Label
var _botoes_idioma: Array[Button] = []


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_timer = Timer.new()
	_timer.one_shot = true
	_timer.wait_time = ATRASO_CONFIRMACAO
	_timer.timeout.connect(_confirmar)
	add_child(_timer)

	_construir_interface()
	_preencher_opcoes()
	_preencher_valores(Database.config)
	_carregando = false
	_mostrar_pagina("hub")


func _notification(what: int) -> void:
	# Ao trocar de idioma, os itens dos menus suspensos precisam ser traduzidos de novo.
	if what == NOTIFICATION_TRANSLATION_CHANGED and _opt_fonte != null:
		var carregando_antes := _carregando
		_carregando = true
		_preencher_opcoes()
		_preencher_valores(Database.config)
		_carregando = carregando_antes


# ---------- Construção da interface ----------

func _construir_interface() -> void:
	if como_overlay:
		var escurecer := ColorRect.new()
		escurecer.color = Color(0, 0, 0, 0.6)
		add_child(escurecer)
		escurecer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	else:
		var fundo := TextureRect.new()
		fundo.texture = load(ARQUIVO_FUNDO)
		fundo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		fundo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		add_child(fundo)
		fundo.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var margem := MarginContainer.new()
	add_child(margem)
	margem.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margem.add_theme_constant_override("margin_left", 110)
	margem.add_theme_constant_override("margin_right", 110)
	margem.add_theme_constant_override("margin_top", 50)
	margem.add_theme_constant_override("margin_bottom", 50)

	var painel := PanelContainer.new()
	painel.add_theme_stylebox_override("panel", _caixa(Color(1, 1, 1, 0.72), 0))
	margem.add_child(painel)

	var interno := MarginContainer.new()
	interno.add_theme_constant_override("margin_left", 36)
	interno.add_theme_constant_override("margin_right", 36)
	interno.add_theme_constant_override("margin_top", 24)
	interno.add_theme_constant_override("margin_bottom", 24)
	painel.add_child(interno)

	var coluna := VBoxContainer.new()
	coluna.add_theme_constant_override("separation", 14)
	interno.add_child(coluna)

	_titulo = _criar_chip("CONFIGURAÇÕES", true)
	_titulo.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	coluna.add_child(_titulo)

	var area := VBoxContainer.new()
	area.size_flags_vertical = Control.SIZE_EXPAND_FILL
	coluna.add_child(area)

	_paginas["hub"] = _construir_hub()
	_paginas["som"] = _construir_som()
	_paginas["texto"] = _construir_texto()
	_paginas["idioma"] = _construir_idioma()
	for p in _paginas.values():
		area.add_child(p)

	var rodape := HBoxContainer.new()
	rodape.alignment = BoxContainer.ALIGNMENT_CENTER
	rodape.add_theme_constant_override("separation", 30)
	coluna.add_child(rodape)

	_botao_restaurar = _criar_botao("Restaurar padrões", Vector2(260, 48))
	_botao_restaurar.pressed.connect(_on_restaurar_pressed)
	rodape.add_child(_botao_restaurar)

	var voltar := _criar_botao("Voltar", Vector2(200, 48))
	voltar.pressed.connect(_on_voltar_pressed)
	rodape.add_child(voltar)


func _construir_hub() -> VBoxContainer:
	var v := _nova_pagina()
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", 26)
	for chave in ["som", "texto", "idioma"]:
		var b := _criar_botao(TITULOS[chave], Vector2(460, 64))
		b.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
		b.add_theme_font_size_override("font_size", 26)
		b.pressed.connect(_mostrar_pagina.bind(chave))
		v.add_child(b)
	return v


func _construir_som() -> VBoxContainer:
	var v := _nova_pagina()
	_sl_musica = _linha_slider(v, "Altura do som (música)", 0.0, 1.0, 0.05, _fmt_percentual)
	_sl_efeitos = _linha_slider(v, "Efeitos sonoros", 0.0, 1.0, 0.05, _fmt_percentual)
	_chk_sem_som = _criar_check("SEM SOM")
	v.add_child(_chk_sem_som)
	return v


func _construir_texto() -> VBoxContainer:
	var v := _nova_pagina()
	_opt_fonte = _linha_opcoes(v, "Tipo da fonte")
	_sl_tamanho = _linha_slider(v, "Tamanho da fonte", 12, 32, 1, _fmt_inteiro)
	_opt_cor = _linha_opcoes(v, "Cor da legenda")
	_sl_espaco = _linha_slider(v, "Espaçamento entre linhas", 0, 20, 1, _fmt_inteiro)
	_sl_velocidade = _linha_slider(v, "Velocidade do texto", 0.5, 2.0, 0.1, _fmt_velocidade)
	_chk_contraste = _criar_check("Modo alto contraste")
	v.add_child(_chk_contraste)

	_painel_previa = PanelContainer.new()
	_painel_previa.size_flags_vertical = Control.SIZE_EXPAND_FILL
	v.add_child(_painel_previa)
	_lbl_previa = Label.new()
	_lbl_previa.text = "Prévia: A detetive Mina observa a cena em silêncio."
	_lbl_previa.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_painel_previa.add_child(_lbl_previa)
	return v


func _construir_idioma() -> VBoxContainer:
	var v := _nova_pagina()
	v.add_child(_criar_chip("Idioma selecionado"))
	var linha := HBoxContainer.new()
	linha.add_theme_constant_override("separation", 20)
	v.add_child(linha)
	var grupo := ButtonGroup.new()
	for item in IDIOMAS:
		var b := _criar_botao(item["rotulo"], Vector2(300, 56))
		b.toggle_mode = true
		b.button_group = grupo
		b.set_meta("codigo", item["codigo"])
		_estilizar_alternancia(b)
		b.pressed.connect(_on_valor_mudou.bind(null))
		linha.add_child(b)
		_botoes_idioma.append(b)
	return v


func _nova_pagina() -> VBoxContainer:
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 12)
	v.size_flags_vertical = Control.SIZE_EXPAND_FILL
	return v


# ---------- Componentes ----------

func _caixa(cor: Color, margem: int = 10, borda: int = 0, cor_borda: Color = Color.BLACK) -> StyleBoxFlat:
	var c := StyleBoxFlat.new()
	c.bg_color = cor
	c.set_content_margin_all(margem)
	if borda > 0:
		c.set_border_width_all(borda)
		c.border_color = cor_borda
	return c


func _criar_chip(texto: String, claro: bool = false) -> Label:
	var l := Label.new()
	l.text = texto
	l.add_theme_font_size_override("font_size", 22)
	if claro:
		l.add_theme_color_override("font_color", Color.BLACK)
		l.add_theme_stylebox_override("normal", _caixa(Color.WHITE, 10))
	else:
		l.add_theme_color_override("font_color", Color.WHITE)
		l.add_theme_stylebox_override("normal", _caixa(Color.BLACK, 10))
	return l


func _estilizar_botao(b: Button) -> void:
	var normal := _caixa(Color.BLACK, 10)
	var hover := _caixa(Color(0.25, 0.25, 0.25), 10)
	var foco := _caixa(Color.BLACK, 10, 4, Color(0.55, 0.55, 0.55))
	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("pressed", normal)
	b.add_theme_stylebox_override("disabled", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("hover_pressed", hover)
	b.add_theme_stylebox_override("focus", foco)
	for nome_cor in ["font_color", "font_pressed_color", "font_hover_color", "font_focus_color", "font_hover_pressed_color"]:
		b.add_theme_color_override(nome_cor, Color.WHITE)
	b.add_theme_font_size_override("font_size", 22)


## Botões "liga/desliga" (idioma): selecionado = fundo branco com borda preta (não depende só de cor).
func _estilizar_alternancia(b: Button) -> void:
	var marcado := _caixa(Color.WHITE, 10, 4, Color.BLACK)
	b.add_theme_stylebox_override("pressed", marcado)
	b.add_theme_stylebox_override("hover_pressed", marcado)
	for nome_cor in ["font_pressed_color", "font_hover_pressed_color"]:
		b.add_theme_color_override(nome_cor, Color.BLACK)


func _criar_botao(texto: String, tamanho: Vector2) -> Button:
	var b := Button.new()
	b.text = texto
	b.custom_minimum_size = tamanho
	_estilizar_botao(b)
	return b


func _criar_check(texto: String) -> CheckButton:
	var c := CheckButton.new()
	c.text = texto
	c.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	_estilizar_botao(c)
	c.toggled.connect(_on_valor_mudou)
	return c


func _linha_slider(pai: Control, texto: String, minimo: float, maximo: float, passo: float, formatar: Callable) -> HSlider:
	var linha := HBoxContainer.new()
	linha.add_theme_constant_override("separation", 16)
	pai.add_child(linha)

	var chip := _criar_chip(texto)
	chip.custom_minimum_size.x = 380
	linha.add_child(chip)

	var s := HSlider.new()
	s.min_value = minimo
	s.max_value = maximo
	s.step = passo
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	s.custom_minimum_size = Vector2(0, 30)
	# Trilho grosso e escuro (a margem interna define a espessura do trilho).
	s.add_theme_stylebox_override("slider", _caixa(Color.BLACK, 6))
	s.add_theme_stylebox_override("grabber_area", _caixa(Color(0.4, 0.4, 0.4), 6))
	s.add_theme_stylebox_override("grabber_area_highlight", _caixa(Color(0.25, 0.25, 0.25), 6))
	linha.add_child(s)

	var valor := _criar_chip("")
	valor.custom_minimum_size.x = 80
	valor.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	linha.add_child(valor)

	s.value_changed.connect(func(v: float) -> void: valor.text = formatar.call(v))
	s.value_changed.connect(_on_valor_mudou)
	s.set_meta("rotulo_valor", valor)
	s.set_meta("formatar", formatar)
	return s


func _linha_opcoes(pai: Control, texto: String) -> OptionButton:
	var linha := HBoxContainer.new()
	linha.add_theme_constant_override("separation", 16)
	pai.add_child(linha)
	var chip := _criar_chip(texto)
	chip.custom_minimum_size.x = 380
	linha.add_child(chip)
	var o := OptionButton.new()
	o.custom_minimum_size = Vector2(340, 44)
	_estilizar_botao(o)
	o.item_selected.connect(_on_valor_mudou)
	linha.add_child(o)
	return o


func _fmt_percentual(v: float) -> String:
	return "%d%%" % roundi(v * 100.0)


func _fmt_inteiro(v: float) -> String:
	return str(int(v))


func _fmt_velocidade(v: float) -> String:
	return "%.1fx" % v


# ---------- Valores <-> controles ----------

func _preencher_opcoes() -> void:
	_opt_fonte.clear()
	for chave in Game.FONTES:
		_opt_fonte.add_item(tr(ROTULOS_FONTE[chave]))
	_opt_cor.clear()
	for chave in CORES_ORDEM:
		_opt_cor.add_item(tr(ROTULOS_COR[chave]))


func _preencher_valores(origem: Dictionary) -> void:
	_sl_musica.value = float(origem["volume_musica"])
	_sl_efeitos.value = float(origem["volume_efeito"])
	_chk_sem_som.button_pressed = bool(origem["sem_som"])
	_opt_fonte.select(maxi(Game.FONTES.find(str(origem["fonte"])), 0))
	_sl_tamanho.value = int(origem["tamanho_texto"])
	_opt_cor.select(maxi(CORES_ORDEM.find(str(origem["cor_legenda"])), 0))
	_sl_espaco.value = int(origem["espacamento"])
	_sl_velocidade.value = float(origem["velocidade_texto"])
	_chk_contraste.button_pressed = bool(origem["alto_contraste"])
	for b in _botoes_idioma:
		b.button_pressed = (b.get_meta("codigo") == str(origem["idioma"]))
	for s in [_sl_musica, _sl_efeitos, _sl_tamanho, _sl_espaco, _sl_velocidade]:
		s.get_meta("rotulo_valor").text = s.get_meta("formatar").call(s.value)
	_atualizar_previa()


func _valores_pagina(pagina: String) -> Dictionary:
	match pagina:
		"som":
			return {
				"volume_musica": _sl_musica.value,
				"volume_efeito": _sl_efeitos.value,
				"sem_som": int(_chk_sem_som.button_pressed),
			}
		"texto":
			return {
				"fonte": Game.FONTES[maxi(_opt_fonte.selected, 0)],
				"tamanho_texto": int(_sl_tamanho.value),
				"cor_legenda": CORES_ORDEM[maxi(_opt_cor.selected, 0)],
				"espacamento": int(_sl_espaco.value),
				"velocidade_texto": _sl_velocidade.value,
				"alto_contraste": int(_chk_contraste.button_pressed),
			}
		"idioma":
			for b in _botoes_idioma:
				if b.button_pressed:
					return {"idioma": b.get_meta("codigo")}
	return {}


func _iguais(a, b) -> bool:
	if typeof(a) == TYPE_FLOAT or typeof(b) == TYPE_FLOAT:
		return is_equal_approx(float(a), float(b))
	return str(a) == str(b)


# ---------- Navegação ----------

func _mostrar_pagina(pagina: String) -> void:
	_confirmar_pendente()
	_pagina_atual = pagina
	for chave in _paginas.keys():
		_paginas[chave].visible = (chave == pagina)
	_titulo.text = TITULOS[pagina]
	_botao_restaurar.visible = pagina != "hub"
	_atualizar_previa()

	# Foco no primeiro controle (navegação por teclado/setas).
	var primeiro := _primeiro_focavel(_paginas[pagina])
	if primeiro:
		primeiro.grab_focus()


func _primeiro_focavel(no: Node) -> Control:
	for filho in no.get_children():
		if filho is Control and filho.focus_mode != Control.FOCUS_NONE and filho.visible:
			return filho
		var achado := _primeiro_focavel(filho)
		if achado:
			return achado
	return null


func _on_voltar_pressed() -> void:
	_confirmar_pendente()
	if _pagina_atual != "hub":
		_mostrar_pagina("hub")
		return
	if como_overlay:
		fechado.emit()
		queue_free()
	else:
		get_tree().change_scene_to_file("res://menu.tscn")


func _on_restaurar_pressed() -> void:
	var base: Dictionary = Database.config.duplicate()
	for chave in _valores_pagina(_pagina_atual).keys():
		base[chave] = Database.PADROES[chave]
	_carregando = true
	_preencher_valores(base)
	_carregando = false
	_on_valor_mudou(null)


# ---------- Confirmação automática das alterações ----------

func _on_valor_mudou(_valor) -> void:
	if _carregando:
		return
	if _pagina_atual == "texto":
		_atualizar_previa()
	_timer.start()


func _confirmar_pendente() -> void:
	if _timer != null and not _timer.is_stopped():
		_timer.stop()
		_confirmar()


func _confirmar() -> void:
	var novos := _valores_pagina(_pagina_atual)
	if novos.is_empty():
		return
	var mudou := false
	for chave in novos.keys():
		if not _iguais(novos[chave], Database.config[chave]):
			mudou = true
	if not mudou:
		Game.mostrar_mensagem("Nenhuma alteração encontrada")
		return
	Database.atualizar_config(novos)
	Game.mostrar_mensagem(MENSAGENS[_pagina_atual])


func _atualizar_previa() -> void:
	if _lbl_previa == null:
		return
	var v := _valores_pagina("texto")
	_lbl_previa.add_theme_font_override("font", Game.criar_fonte(str(v["fonte"])))
	_lbl_previa.add_theme_font_size_override("font_size", int(v["tamanho_texto"]))
	_lbl_previa.add_theme_color_override("font_color", Game.CORES_LEGENDA.get(str(v["cor_legenda"]), Color.WHITE))
	_lbl_previa.add_theme_constant_override("line_spacing", int(v["espacamento"]))
	var contraste := bool(v["alto_contraste"])
	var estilo := _caixa(Color(0, 0, 0, 1.0 if contraste else 0.82), 14, 3 if contraste else 0, Color.WHITE)
	_painel_previa.add_theme_stylebox_override("panel", estilo)
